#define pinBUZZER D8    //D8
#define pinSTART D7  // D7 로터리 엔코더 버튼
#define ROTARY_ENCODER_A_PIN D5 //DT
#define ROTARY_ENCODER_B_PIN D6 //CLK
#define ROTARY_ENCODER_BUTTON_PIN D7 
#define ROTARY_ENCODER_VCC_PIN -1   //Direct
#define ROTARY_ENCODER_STEPS 4

#define D0 16
#define D1 5
#define D2 4
#define D3 0
#define D4 2
#define D5 14
#define D6 12
#define D7 13
#define D8 15
#define BDRX 3
#define BDTX 1

#define main_min 0
#define main_max 1
#define setting_min 0
#define setting_max 2
#define learning_min 0
#define learning_max 5
#define repeat_min 1
#define repeat_max 20

#define WAIT_MP3 { delay(10); while(mp3.getStatus()==MP3_STATUS_PLAYING); delay(10); }


/****************MP3_NUM********************/
#define DOG 1 //find dog
#define CAT 2 //find cat
#define HOR 3 //find horse
#define COW 4 //find cow
#define Cor 5 //correct
#define Wro 6 //wrong
#define Thr 7 //three
#define Two 8 //two
#define One 9 //one
#define GStart 10 //game start
/*******************************************/

int bpm = 140;
int bpm_offset = 2561;

void wait(bool no);
void play(unsigned int sound, unsigned int note);
void repeat_melody(int cnt);

void wait(bool no){
    pinMode(pinSTART,INPUT_PULLUP);
    //repeat_melody(1);
    if(no==1){
        while(1){
            delay(10);
            if(digitalRead(pinSTART) == 0) break;
        }
    }
    repeat_melody(2);
}

void play(unsigned int sound, unsigned int note){
    note *= (bpm_offset/bpm);
    tone(pinBUZZER, sound, note);
    delay(note*1.30);
}

void repeat_melody(int cnt){
    pinMode(pinBUZZER, OUTPUT);
    for(int i=0; i<cnt; i++){
        for(int j=1500; j<2500; j+=50){
            tone(pinBUZZER, j, 20); delay(10);
        }
    }
}
